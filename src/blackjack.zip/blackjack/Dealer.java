package blackjack;

import blackjack.services.DealerService;
import blackjack.services.DeckService;

public class Dealer {
    private final DealerService dealerService;

    public Dealer() {
        dealerService = new DealerService();
    }

    public void dealInitialCards(DeckService deck, Player player) {
        dealerService.dealInitialCards(deck, player);
    }

    public void playTurn(DeckService deck) {
        dealerService.playTurn(deck);
    }

    public Hand getHand() {
        return dealerService.getHand();
    }

}
