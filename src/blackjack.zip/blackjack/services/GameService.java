package blackjack.services;

import blackjack.Card;
import blackjack.Game;
import blackjack.Hand;
import blackjack.Player;

import java.util.List;
import java.util.Scanner;

public class GameService {

    private final DeckService deckService;
    private final Player player;
    private final DealerService dealerService;
    private static final String DEALER_MESSAGE = "        Dealers Hand: ";

    public GameService() {
        deckService = new DeckService();
        player = new Player("Player");
        dealerService = new DealerService();
    }

    public void start() {
        System.out.println("=========================");
        System.out.println("| Welcome to Blackjack! |");
        System.out.println("=========================");

        deckService.shuffle();

        // Deal initial cards
        dealerService.dealInitialCards(deckService, player);
        showHands();

        // Player's turn
        playerTurn();

        // Dealer's turn
        dealerTurn();

    }

    public void playAgain() {
        Scanner scanner = new Scanner(System.in);
        String choice;

        System.out.print("Would you like to play again?: (Y)es or (N)o: ");
        choice = scanner.nextLine().trim().toLowerCase();

        if ("y".equalsIgnoreCase(choice)) {
            Game game = new Game();
            game.start();
        }
    }

    public void playerTurn() {
        Scanner scanner = new Scanner(System.in);
        String choice;

        while (true) {
            System.out.print("Choose an action: (H)it or (S)tand: ");
            choice = scanner.nextLine().trim().toLowerCase();

            if ("h".equals(choice)) {
                Card card = deckService.dealCard();
                player.addCardToHand(card);
                showHands();
                if (player.getHand().is21() || player.getHand().isBusted()) {
                    determineWinner();
                }
            } else if ("s".equals(choice)) {
                break;
            } else {
                System.out.println("Invalid input. Please try again.");
            }
        }
    }

    public void dealerTurn() {
        if (!player.getHand().isBusted()) {
            dealerService.playTurn(deckService);
        }
        determineWinner();
    }

    public void determineWinner() {
        int playerValue = player.getHand().calculateValue();
        int dealerValue = dealerService.getHand().calculateValue();

        if (player.getHand().is21()) {
            System.out.println("You win!" + DEALER_MESSAGE + getDealerfullHandString(dealerService));
        } else if (player.getHand().isBusted()) {
            System.out.println("You lose. Busted!" + DEALER_MESSAGE + getDealerfullHandString(dealerService));
        } else if (dealerService.getHand().isBusted()) {
            System.out.println("Dealer busts. You win!" + DEALER_MESSAGE + getDealerfullHandString(dealerService));
        } else if (playerValue > dealerValue) {
            System.out.println("You win!" + DEALER_MESSAGE + getDealerfullHandString(dealerService));
        } else if (playerValue < dealerValue) {
            System.out.println("You lose." + DEALER_MESSAGE + getDealerfullHandString(dealerService));
        } else {
            System.out.println("It's a tie!");
        }

        reset();
    }

    public String getDealerfullHandString(DealerService dealer) {
        return getHand(dealer.getHand());
    }

    public String getHand(Hand hand) {
        List<Card> cards = hand.getCards();
        StringBuilder sb = new StringBuilder();

        for (Card card : cards) {
            sb.append(card.rank()).append(card.getFormattedSuit()).append(" ");
        }

        sb.append(" (Value: ").append(hand.calculateValue()).append(")");

        return sb.toString();
    }

    public void showHands() {
        System.out.println("Player's hand: " + getPlayerHandString(player));
        System.out.println("Dealer's hand: " + getDealerHiddenHandString(dealerService));

        if (player.getHand().is21()) {
            determineWinner();
        }
    }

    public String getDealerHiddenHandString(DealerService dealer) {
        List<Card> cards = dealer.getHand().getCards();
        StringBuilder sb = new StringBuilder();

        if (!cards.isEmpty()) {
            sb.append(cards.get(0).rank()).append(cards.get(0).getFormattedSuit()).append(" [FaceDown]");
        }

        return sb.toString();
    }

    public String getPlayerHandString(Player player) {
        return getHand(player.getHand());
    }

    public void reset() {
        player.getHand().clear();
        dealerService.getHand().clear();

        // Play again?
        playAgain();
    }

}
