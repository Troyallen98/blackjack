package blackjack;

public class Deck {
}
